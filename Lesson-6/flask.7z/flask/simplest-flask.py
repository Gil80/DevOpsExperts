from flask import Flask
from flask import request


app = Flask(__name__)


@app.route("/", methods=['GET'])
def index():
    print('I am in index')
    return {"name": "Hello experts"}

app.run(port=5001, debug=True)
