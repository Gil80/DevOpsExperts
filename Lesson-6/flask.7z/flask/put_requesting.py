import requests
repos = requests.put("http://localhost:5001/")

print(repos.status_code)