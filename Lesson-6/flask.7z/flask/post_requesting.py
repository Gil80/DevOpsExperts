import requests
repos = requests.post("http://localhost:5001/divide",json={"first":"15","second":"2"})

print(repos.json())